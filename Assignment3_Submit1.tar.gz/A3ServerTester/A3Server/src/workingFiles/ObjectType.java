package workingFiles;

public abstract class ObjectType {
	
	public ObjectType(){}
}
