package workingFiles;

public class Collections extends ObjectType {

	private int ID;
	public Collections (){
		this.ID = this.hashCode();
	}
}
